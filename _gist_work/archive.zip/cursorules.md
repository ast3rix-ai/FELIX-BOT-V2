Replace this file with your preferred Cursor rules text.

Temporary placeholder so the repository contains the expected file.


